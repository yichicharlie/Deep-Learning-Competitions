# Deep-Learning-Compitition

In class Kaggle competition ( Fall 2018 )

Team name: 卍閃傲o剎帝卍

Team members:

陳俊穎 Chen, Chun Ying

曾奕齊 Tseng, Yi-Chi

吳亦振 Wu, Yi-Chen

曾立豪 Zeng, Li Hao 
